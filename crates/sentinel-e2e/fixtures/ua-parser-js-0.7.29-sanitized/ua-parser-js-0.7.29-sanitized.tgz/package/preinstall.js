// Synthetic supply-chain attack shape — reproduces postinstall->network-egress
// without containing any real malicious bytes. Sentinel VAL-01 asserts that
// the connection attempt below is intercepted and denied.
'use strict';
var net = require('net');
process.stdout.write('ua-parser-js-mock: attempting connect to c2-sink.test.invalid:443\n');
var sock = net.createConnection({ host: 'c2-sink.test.invalid', port: 443 });
sock.on('error', function () { /* swallow — Sentinel may EHOSTUNREACH us */ });
sock.on('connect', function () { try { sock.destroy(); } catch (_) {} });
// Exit 0 immediately so npm install does not abort before Sentinel's
// JSONL Decision row is observable. The connection attempt is the
// observable side-effect VAL-01 asserts on.
process.exit(0);
